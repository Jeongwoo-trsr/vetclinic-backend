

<?php $__env->startSection('title', 'Announcements'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4">
    <div class="bg-white shadow-lg rounded-lg p-6">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold text-[#2d3748]">Announcements</h1>
            <?php if(Auth::user()->isAdmin() || Auth::user()->isDoctor()): ?>
                <a href="<?php echo e(route('announcements.create')); ?>" class="bg-[#0066cc] text-white px-4 py-2 rounded-lg hover:bg-[#003d82]">
                    <i class="fas fa-plus mr-2"></i>Create Announcement
                </a>
            <?php endif; ?>
        </div>

        <!-- Search Bar -->
        <div style="margin-bottom: 3rem;">
            <form method="GET" action="<?php echo e(route('announcements.index')); ?>" class="flex gap-4">
                <input 
                    type="text" 
                    name="search" 
                    placeholder="Search announcements..." 
                    value="<?php echo e(request('search')); ?>"
                    class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0066cc]"
                >
                <button type="submit" class="bg-[#0066cc] text-white px-6 py-2 rounded-lg hover:bg-[#003d82]">
                    Search
                </button>
                <?php if(request('search')): ?>
                    <a href="<?php echo e(route('announcements.index')); ?>" class="bg-gray-300 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-400">
                        Clear
                    </a>
                <?php endif; ?>
            </form>
        </div>

        <!-- Announcements List -->
        <div class="space-y-4">
            <?php $__empty_1 = true; $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="bg-white border-l-4 border-[#0066cc] shadow rounded-lg p-4">
                    <div class="flex justify-between items-start mb-2">
                        <h3 class="text-lg font-bold text-[#2d3748]"><?php echo e($announcement->title); ?></h3>
                        <span class="text-sm text-gray-500"><?php echo e($announcement->created_at->format('M d, Y')); ?></span>
                    </div>
                    
                    <p class="text-gray-700 mb-3"><?php echo e(Str::limit($announcement->content, 200)); ?></p>
                    
                    <div class="flex justify-between items-center">
                        <div class="text-sm text-gray-500">
                            <i class="fas fa-user mr-1"></i>
                            Posted by <?php echo e($announcement->creator->name); ?>

                        </div>
                        
                        <?php if(Auth::user()->isAdmin() || Auth::user()->isDoctor()): ?>
                            <div class="flex items-center gap-4">
                                <a href="<?php echo e(route('announcements.edit', $announcement)); ?>" class="text-[#d4931d] hover:text-[#fcd34d] flex items-center gap-1">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <form method="POST" action="<?php echo e(route('announcements.destroy', $announcement)); ?>" class="inline-block" onsubmit="return confirm('Are you sure you want to delete this announcement?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 hover:text-red-800 flex items-center gap-1">
                                        <i class="fas fa-trash"></i> Delete
                                    </button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center py-8 text-gray-500">
                    <i class="fas fa-bullhorn text-4xl mb-4"></i>
                    <p>No announcements found.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <div class="mt-6">
            <?php echo e($announcements->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Frenzy\veterinary_laravel\resources\views\announcements\index.blade.php ENDPATH**/ ?>