

<?php $__env->startSection('title', 'Medical Record Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4">
    <div class="mb-6 flex justify-between items-center">
        <div>
            <h1 class="text-3xl font-bold" style="color: #2c3e50;">Medical Record Details</h1>
            <p class="mt-1" style="color: #5d6d7e;"><?php echo e($medicalRecord->pet->name); ?> - <?php echo e($medicalRecord->created_at->format('M d, Y')); ?></p>
        </div>
        <div class="flex gap-3">
            <!-- Back button for all users -->
            <button type="button" onclick="history.back()" class="px-4 py-2 rounded-lg" style="background-color: #95a5a6; color: #ffffff;">
                <i class="fas fa-arrow-left mr-2"></i>
                Back
            </button>
        </div>
    </div>

    <!-- Patient Information -->
    <div class="shadow-lg rounded-lg mb-6 border-2" style="background-color: #ffffff; border-color: #0d5cb6;">
        <div class="px-6 py-3" style="background-color: #34495e;">
            <h2 class="text-lg font-semibold text-white">Patient Information</h2>
        </div>
        <div class="p-6 grid grid-cols-1 md:grid-cols-3 gap-4" style="background-color: #ffffff;">
            <div>
                <p class="text-sm" style="color: #5d6d7e;">Pet Name</p>
                <p class="text-base font-medium" style="color: #2c3e50;"><?php echo e($medicalRecord->pet->name); ?></p>
            </div>
            <div>
                <p class="text-sm" style="color: #5d6d7e;">Species</p>
                <p class="text-base font-medium" style="color: #2c3e50;"><?php echo e($medicalRecord->pet->species ?? 'N/A'); ?></p>
            </div>
            <div>
                <p class="text-sm" style="color: #5d6d7e;">Breed</p>
                <p class="text-base font-medium" style="color: #2c3e50;"><?php echo e($medicalRecord->pet->breed ?? 'N/A'); ?></p>
            </div>
            <div>
                <p class="text-sm" style="color: #5d6d7e;">Owner</p>
                <p class="text-base font-medium" style="color: #2c3e50;"><?php echo e($medicalRecord->pet->owner->user->name); ?></p>
            </div>
            <div>
                <p class="text-sm" style="color: #5d6d7e;">Doctor</p>
                <p class="text-base font-medium" style="color: #2c3e50;"><?php echo e($medicalRecord->doctor->user->name ?? 'N/A'); ?></p>
            </div>
            <div>
                <p class="text-sm" style="color: #5d6d7e;">Record Date</p>
                <p class="text-base font-medium" style="color: #2c3e50;"><?php echo e($medicalRecord->created_at->format('M d, Y h:i A')); ?></p>
            </div>
        </div>
    </div>

    <!-- Diagnosis and Treatment -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div class="bg-white shadow-lg rounded-lg border-2" style="border-color: #0502a1ff;">
            <div class="px-6 py-3" style="background-color: #34495e;">
                <h2 class="text-lg font-semibold text-white">Diagnosis</h2>
            </div>
            <div class="p-6">
                <p class="whitespace-pre-wrap" style="color: #5d6d7e;"><?php echo e($medicalRecord->diagnosis); ?></p>
            </div>
        </div>

        <div class="bg-white shadow-lg rounded-lg border-2" style="border-color: #0502a1ff;">
            <div class="px-6 py-3" style="background-color: #34495e;">
                <h2 class="text-lg font-semibold text-white">Treatment</h2>
            </div>
            <div class="p-6">
                <p class="whitespace-pre-wrap" style="color: #5d6d7e;"><?php echo e($medicalRecord->treatment); ?></p>
            </div>
        </div>
    </div>

    <!-- Prescription -->
    <?php if($medicalRecord->prescription): ?>
    <div class="bg-white shadow-lg rounded-lg mb-6 border-2" style="border-color: #0502a1ff;">
        <div class="px-6 py-3" style="background-color: #34495e;">
            <h2 class="text-lg font-semibold text-white">General Prescription Notes</h2>
        </div>
        <div class="p-6">
            <p class="whitespace-pre-wrap" style="color: #5d6d7e;"><?php echo e($medicalRecord->prescription); ?></p>
        </div>
    </div>
    <?php endif; ?>

    <!-- Medications -->
    <?php if($medicalRecord->prescriptions->count() > 0): ?>
    <div class="bg-white shadow-lg rounded-lg mb-6 border-2" style="border-color: #0502a1ff;">
        <div class="px-6 py-3" style="background-color: #34495e;">
            <h2 class="text-lg font-semibold text-white">Medications</h2>
        </div>
        <div class="p-6">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y" style="border-color: #e5e7eb;">
                    <thead style="background-color: #ecf0f1;">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium uppercase" style="color: #2c3e50;">Medication</th>
                            <th class="px-6 py-3 text-left text-xs font-medium uppercase" style="color: #2c3e50;">Dosage</th>
                            <th class="px-6 py-3 text-left text-xs font-medium uppercase" style="color: #2c3e50;">Frequency</th>
                            <th class="px-6 py-3 text-left text-xs font-medium uppercase" style="color: #2c3e50;">Duration</th>
                            <th class="px-6 py-3 text-left text-xs font-medium uppercase" style="color: #2c3e50;">Instructions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y" style="border-color: #e5e7eb;">
                        <?php $__currentLoopData = $medicalRecord->prescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-6 py-4 text-sm" style="color: #2c3e50;"><?php echo e($prescription->medication_name); ?></td>
                            <td class="px-6 py-4 text-sm" style="color: #5d6d7e;"><?php echo e($prescription->dosage ?? '-'); ?></td>
                            <td class="px-6 py-4 text-sm" style="color: #5d6d7e;"><?php echo e($prescription->frequency ?? '-'); ?></td>
                            <td class="px-6 py-4 text-sm" style="color: #5d6d7e;"><?php echo e($prescription->duration_days ? $prescription->duration_days . ' days' : '-'); ?></td>
                            <td class="px-6 py-4 text-sm" style="color: #5d6d7e;"><?php echo e($prescription->instructions ?? '-'); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Follow-up Information -->
    <?php if($medicalRecord->followUpSchedules->count() > 0): ?>
    <div class="bg-white shadow-lg rounded-lg mb-6 border-2" style="border-color: #0d5cb6;">
        <div class="px-6 py-3" style="background-color: #34495e;">
            <h2 class="text-lg font-semibold text-white">Follow-up Schedule</h2>
        </div>
        <div class="p-6 space-y-4">
            <?php $__currentLoopData = $medicalRecord->followUpSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $followUp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="border rounded-lg p-4 bg-white" style="border-color: #e5e7eb;">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-sm" style="color: #5d6d7e;">Scheduled Date</p>
                        <p class="text-base font-medium" style="color: #2c3e50;"><?php echo e($followUp->scheduled_date->format('M d, Y')); ?></p>
                    </div>
                    <span class="px-3 py-1 text-sm font-semibold rounded-full" 
                        style="<?php if($followUp->status === 'pending'): ?> background-color: #f9a825; color: #ffffff;
                        <?php elseif($followUp->status === 'completed'): ?> background-color: #28a745; color: #ffffff;
                        <?php else: ?> background-color: #95a5a6; color: #ffffff; <?php endif; ?>">
                        <?php echo e(ucfirst($followUp->status)); ?>

                    </span>
                </div>
                <?php if($followUp->notes): ?>
                <div class="mt-3">
                    <p class="text-sm" style="color: #5d6d7e;">Notes</p>
                    <p style="color: #5d6d7e;"><?php echo e($followUp->notes); ?></p>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<style>
button:hover {
    opacity: 0.9;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Frenzy\veterinary_laravel\resources\views\medical-records\show.blade.php ENDPATH**/ ?>