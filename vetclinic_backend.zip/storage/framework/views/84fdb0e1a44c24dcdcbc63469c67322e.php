

<?php $__env->startSection('title', 'Doctors'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-6">Doctors</h1>

<div class="bg-blue-100 shadow-lg rounded-lg p-6">
    <?php if($doctors->count()): ?>
        <table class="min-w-full border border-gray-200 divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3">#</th>
                    <th class="px-6 py-3">Name</th>
                    <th class="px-6 py-3">Email</th>
                    <th class="px-6 py-3">Specialization</th>
                    <th class="px-6 py-3 text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-6 py-4"><?php echo e($loop->iteration); ?></td>
                    <td class="px-6 py-4"><?php echo e($doctor->user->name); ?></td>
                    <td class="px-6 py-4"><?php echo e($doctor->user->email); ?></td>
                    <td class="px-6 py-4"><?php echo e($doctor->specialization ?? 'N/A'); ?></td>
                    <td class="px-6 py-4 text-center">
                        <form action="<?php echo e(route('admin.doctors.destroy', $doctor->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this doctor?');" class="inline-block">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="mt-4"><?php echo e($doctors->links()); ?></div>
    <?php else: ?>
        <p class="text-gray-500">No doctors found.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Frenzy\veterinary_laravel\resources\views\admin\doctors.blade.php ENDPATH**/ ?>