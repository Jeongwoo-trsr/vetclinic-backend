

<?php $__env->startSection('title', 'Add Medical Record'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <div class="bg-white shadow rounded-lg">
        <div class="px-4 py-5 sm:p-6">
            <h1 class="text-2xl font-bold mb-6" style="color: #2c3e50;">Add Medical Record</h1>

            <form method="POST" action="<?php echo e(route('medical-records.store')); ?>" class="space-y-6">
                <?php echo csrf_field(); ?>

                <!-- Pet and Doctor Selection -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="pet_id" class="block text-sm font-medium" style="color: #2c3e50;">Pet</label>
                        <select id="pet_id" name="pet_id" required 
                                class="mt-1 block w-full px-3 py-2 border bg-white rounded-md shadow-sm focus:outline-none sm:text-sm <?php $__errorArgs = ['pet_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="border-color: #d1d5db;">
                            <option value="">Select pet</option>
                            <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pet->id); ?>" <?php echo e(old('pet_id') == $pet->id ? 'selected' : ''); ?>>
                                <?php echo e($pet->name); ?> (<?php echo e($pet->owner->user->name); ?>)
                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['pet_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm" style="color: #d32f2f;"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label for="doctor_id" class="block text-sm font-medium" style="color: #2c3e50;">Doctor</label>
                        <select id="doctor_id" name="doctor_id" required 
                                class="mt-1 block w-full px-3 py-2 border bg-white rounded-md shadow-sm focus:outline-none sm:text-sm <?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="border-color: #d1d5db;">
                            <option value="">Select doctor</option>
                            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($doctor->id); ?>" <?php echo e(old('doctor_id') == $doctor->id ? 'selected' : ''); ?>>
                                <?php echo e($doctor->user->name); ?> (<?php echo e($doctor->specialization); ?>)
                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm" style="color: #d32f2f;"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Appointment Selection -->
                <div>
                    <label for="appointment_id" class="block text-sm font-medium" style="color: #2c3e50;">Related Appointment (Optional)</label>
                    <select id="appointment_id" name="appointment_id" 
                            class="mt-1 block w-full px-3 py-2 border bg-white rounded-md shadow-sm focus:outline-none sm:text-sm <?php $__errorArgs = ['appointment_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="border-color: #d1d5db;">
                        <option value="">Select appointment</option>
                        <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($appointment->id); ?>" <?php echo e(old('appointment_id') == $appointment->id ? 'selected' : ''); ?>>
                            <?php echo e($appointment->pet->name); ?> - <?php echo e($appointment->service->name); ?> (<?php echo e($appointment->appointment_date->format('M d, Y')); ?>)
                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['appointment_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm" style="color: #d32f2f;"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Diagnosis -->
                <div>
                    <label for="diagnosis" class="block text-sm font-medium" style="color: #2c3e50;">Diagnosis</label>
                    <textarea id="diagnosis" name="diagnosis" rows="4" required 
                              class="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none sm:text-sm <?php $__errorArgs = ['diagnosis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                              style="border-color: #d1d5db;"
                              placeholder="Enter diagnosis details..."><?php echo e(old('diagnosis')); ?></textarea>
                    <?php $__errorArgs = ['diagnosis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm" style="color: #d32f2f;"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Treatment -->
                <div>
                    <label for="treatment" class="block text-sm font-medium" style="color: #2c3e50;">Treatment</label>
                    <textarea id="treatment" name="treatment" rows="4" required 
                              class="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none sm:text-sm <?php $__errorArgs = ['treatment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                              style="border-color: #d1d5db;"
                              placeholder="Enter treatment details..."><?php echo e(old('treatment')); ?></textarea>
                    <?php $__errorArgs = ['treatment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm" style="color: #d32f2f;"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- General Prescription Notes -->
                <div>
                    <label for="prescription" class="block text-sm font-medium" style="color: #2c3e50;">General Prescription Notes</label>
                    <textarea id="prescription" name="prescription" rows="3" 
                              class="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none sm:text-sm <?php $__errorArgs = ['prescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                              style="border-color: #d1d5db;"
                              placeholder="Enter general prescription notes..."><?php echo e(old('prescription')); ?></textarea>
                    <?php $__errorArgs = ['prescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm" style="color: #d32f2f;"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Medications -->
                <div>
                    <label class="block text-sm font-medium mb-2" style="color: #2c3e50;">Medications</label>
                    <div id="medications-container">
                        <div class="medication-row grid grid-cols-1 md:grid-cols-5 gap-4 mb-4 p-4 border rounded-lg" style="border-color: #e5e7eb;">
                            <div>
                                <label class="block text-xs font-medium" style="color: #5d6d7e;">Medication Name</label>
                                <input type="text" name="medications[0][name]" 
                                       class="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none sm:text-sm" 
                                       style="border-color: #d1d5db;"
                                       placeholder="e.g., Amoxicillin">
                            </div>
                            <div>
                                <label class="block text-xs font-medium" style="color: #5d6d7e;">Dosage</label>
                                <input type="text" name="medications[0][dosage]" 
                                       class="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none sm:text-sm" 
                                       style="border-color: #d1d5db;"
                                       placeholder="e.g., 250mg">
                            </div>
                            <div>
                                <label class="block text-xs font-medium" style="color: #5d6d7e;">Frequency</label>
                                <input type="text" name="medications[0][frequency]" 
                                       class="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none sm:text-sm" 
                                       style="border-color: #d1d5db;"
                                       placeholder="e.g., Twice daily">
                            </div>
                            <div>
                                <label class="block text-xs font-medium" style="color: #5d6d7e;">Duration (days)</label>
                                <input type="number" name="medications[0][duration_days]" min="1" 
                                       class="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none sm:text-sm" 
                                       style="border-color: #d1d5db;"
                                       placeholder="7">
                            </div>
                            <div>
                                <label class="block text-xs font-medium" style="color: #5d6d7e;">Instructions</label>
                                <input type="text" name="medications[0][instructions]" 
                                       class="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none sm:text-sm" 
                                       style="border-color: #d1d5db;"
                                       placeholder="e.g., With food">
                            </div>
                        </div>
                    </div>
                    <button type="button" id="add-medication" class="inline-flex items-center px-3 py-2 border text-sm font-medium rounded-md bg-white" style="border-color: #d1d5db; color: #2c3e50;">
                        <i class="fas fa-plus mr-2"></i>
                        Add Medication
                    </button>
                </div>

                <!-- Follow-up Schedule -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="follow_up_date" class="block text-sm font-medium" style="color: #2c3e50;">Follow-up Date</label>
                        <input id="follow_up_date" name="follow_up_date" type="date" 
                               class="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none sm:text-sm <?php $__errorArgs = ['follow_up_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               style="border-color: #d1d5db;"
                               value="<?php echo e(old('follow_up_date')); ?>">
                        <?php $__errorArgs = ['follow_up_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm" style="color: #d32f2f;"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label for="follow_up_notes" class="block text-sm font-medium" style="color: #2c3e50;">Follow-up Notes</label>
                        <input id="follow_up_notes" name="follow_up_notes" type="text" 
                               class="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none sm:text-sm" 
                               style="border-color: #d1d5db;"
                               placeholder="Follow-up instructions..." value="<?php echo e(old('follow_up_notes')); ?>">
                    </div>
                </div>

                <!-- Submit Buttons -->
                <div class="flex justify-end space-x-3">
                    <a href="<?php echo e(route('medical-records.index')); ?>" class="inline-flex items-center px-4 py-2 border text-sm font-medium rounded-md bg-white" style="border-color: #d1d5db; color: #2c3e50;">
                        Cancel
                    </a>
                    <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white" style="background-color: #0d5cb6;">
                        <i class="fas fa-save mr-2"></i>
                        Create Medical Record
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
let medicationIndex = 1;

document.getElementById('add-medication').addEventListener('click', function() {
    const container = document.getElementById('medications-container');
    const newRow = document.createElement('div');
    newRow.className = 'medication-row grid grid-cols-1 md:grid-cols-5 gap-4 mb-4 p-4 border rounded-lg';
    newRow.style.borderColor = '#e5e7eb';
    newRow.innerHTML = `
        <div>
            <label class="block text-xs font-medium" style="color: #5d6d7e;">Medication Name</label>
            <input type="text" name="medications[${medicationIndex}][name]" 
                   class="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none sm:text-sm" 
                   style="border-color: #d1d5db;"
                   placeholder="e.g., Amoxicillin">
        </div>
        <div>
            <label class="block text-xs font-medium" style="color: #5d6d7e;">Dosage</label>
            <input type="text" name="medications[${medicationIndex}][dosage]" 
                   class="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none sm:text-sm" 
                   style="border-color: #d1d5db;"
                   placeholder="e.g., 250mg">
        </div>
        <div>
            <label class="block text-xs font-medium" style="color: #5d6d7e;">Frequency</label>
            <input type="text" name="medications[${medicationIndex}][frequency]" 
                   class="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none sm:text-sm" 
                   style="border-color: #d1d5db;"
                   placeholder="e.g., Twice daily">
        </div>
        <div>
            <label class="block text-xs font-medium" style="color: #5d6d7e;">Duration (days)</label>
            <input type="number" name="medications[${medicationIndex}][duration_days]" min="1" 
                   class="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none sm:text-sm" 
                   style="border-color: #d1d5db;"
                   placeholder="7">
        </div>
        <div>
            <label class="block text-xs font-medium" style="color: #5d6d7e;">Instructions</label>
            <input type="text" name="medications[${medicationIndex}][instructions]" 
                   class="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none sm:text-sm" 
                   style="border-color: #d1d5db;"
                   placeholder="e.g., With food">
        </div>
    `;
    container.appendChild(newRow);
    medicationIndex++;
});
</script>

<style>
button:hover, a:hover {
    opacity: 0.9;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Frenzy\veterinary_laravel\resources\views\medical-records\create.blade.php ENDPATH**/ ?>