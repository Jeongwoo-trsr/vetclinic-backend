

<?php $__env->startSection('title', 'Pet Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-[#2d3748]">
            <i class="fas fa-info-circle text-[#fcd34d] mr-2"></i>Pet Details
        </h1>
        <div class="flex gap-2">
            <a href="<?php echo e(route('pets.edit', $pet->id)); ?>" class="px-4 py-2 bg-[#d4931d] text-white rounded hover:bg-[#fcd34d] hover:text-[#2d3748]">
                <i class="fas fa-edit mr-2"></i>Edit
            </a>
            <a href="<?php echo e(Auth::user()->role === 'admin' ? route('admin.pets') : route('pet-owner.pets')); ?>" class="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400">
                <i class="fas fa-arrow-left mr-2"></i>Back
            </a>
        </div>
    </div>

    <div class="bg-white shadow-lg rounded-lg overflow-hidden">
       <!-- Header -->
        <div class="bg-[#1e3a5f] px-8 py-8">
            <div>
                <h2 class="text-4xl font-bold mb-2 text-white">
                    <i class="fas fa-paw text-[#fcd34d] mr-3"></i><?php echo e($pet->name); ?>

                </h2>
                <p class="text-gray-200 text-lg"><?php echo e($pet->species); ?> - <?php echo e($pet->breed ?? 'Mixed'); ?></p>
            </div>
        </div>


        <!-- Pet Information -->
        <div class="p-6">
            <div class="grid grid-cols-2 gap-6 mb-6">
                <div>
                    <h3 class="text-lg font-semibold mb-4 text-[#2d3748]">
                        <i class="fas fa-clipboard-list text-[#fcd34d] mr-2"></i>Basic Information
                    </h3>
                    <div class="space-y-3">
                        <div>
                            <label class="text-sm text-gray-600">
                                <i class="fas fa-list text-[#d4931d] mr-1"></i>Species
                            </label>
                            <p class="font-medium"><?php echo e($pet->species); ?></p>
                        </div>
                        <div>
                            <label class="text-sm text-gray-600">
                                <i class="fas fa-dog text-[#fcd34d] mr-1"></i>Breed
                            </label>
                            <p class="font-medium"><?php echo e($pet->breed ?? 'N/A'); ?></p>
                        </div>
                        <div>
                            <label class="text-sm text-gray-600">
                                <i class="fas fa-birthday-cake text-[#d4931d] mr-1"></i>Age
                            </label>
                            <p class="font-medium"><?php echo e($pet->age); ?> years old</p>
                        </div>
                        <div>
                            <label class="text-sm text-gray-600">
                                <i class="fas fa-venus-mars text-[#fcd34d] mr-1"></i>Gender
                            </label>
                            <p class="font-medium"><?php echo e(ucfirst($pet->gender)); ?></p>
                        </div>
                    </div>
                </div>

                <div>
                    <h3 class="text-lg font-semibold mb-4 text-[#2d3748]">
                        <i class="fas fa-ruler text-[#fcd34d] mr-2"></i>Physical Details
                    </h3>
                    <div class="space-y-3">
                        <div>
                            <label class="text-sm text-gray-600">
                                <i class="fas fa-weight text-[#d4931d] mr-1"></i>Weight
                            </label>
                            <p class="font-medium"><?php echo e($pet->weight ? $pet->weight . ' kg' : 'N/A'); ?></p>
                        </div>
                        <div>
                            <label class="text-sm text-gray-600">
                                <i class="fas fa-palette text-[#fcd34d] mr-1"></i>Color
                            </label>
                            <p class="font-medium"><?php echo e($pet->color ?? 'N/A'); ?></p>
                        </div>
                    
                    </div>
                </div>
            </div>

            <!-- Owner Information -->
            <div class="border-t pt-6 mb-6">
                <h3 class="text-lg font-semibold mb-4 text-[#2d3748]">
                    <i class="fas fa-user text-[#fcd34d] mr-2"></i>Owner Information
                </h3>
                <div class="bg-gray-50 p-4 rounded-lg">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="text-sm text-gray-600">Owner Name</label>
                            <p class="font-medium"><?php echo e($pet->owner->user->name); ?></p>
                        </div>
                        <div>
                            <label class="text-sm text-gray-600">Email</label>
                            <p class="font-medium"><?php echo e($pet->owner->user->email); ?></p>
                        </div>
                        <div>
                            <label class="text-sm text-gray-600">Phone</label>
                            <p class="font-medium"><?php echo e($pet->owner->user->phone ?? 'N/A'); ?></p>
                        </div>
                        <div>
                            <label class="text-sm text-gray-600">Emergency Contact</label>
                            <p class="font-medium"><?php echo e($pet->owner->emergency_contact ?? 'N/A'); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Medical Notes -->
            <?php if($pet->medical_notes): ?>
            <div class="border-t pt-6">
                <h3 class="text-lg font-semibold mb-4 text-[#2d3748]">
                    <i class="fas fa-notes-medical text-[#fcd34d] mr-2"></i>Medical Notes
                </h3>
                <div class="bg-[#fcd34d] bg-opacity-20 border border-[#fcd34d] p-4 rounded-lg">
                    <p class="text-gray-700"><?php echo e($pet->medical_notes); ?></p>
                </div>
            </div>
            <?php endif; ?>

            <!-- Appointments History -->
            <?php if($pet->appointments && $pet->appointments->count() > 0): ?>
            <div class="border-t pt-6 mt-6">
                <h3 class="text-lg font-semibold mb-4 text-[#2d3748]">
                    <i class="fas fa-calendar-check text-[#fcd34d] mr-2"></i>Recent Appointments
                </h3>
                <div class="space-y-2">
                    <?php $__currentLoopData = $pet->appointments->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-gray-50 p-3 rounded flex justify-between items-center">
                        <div>
                            <p class="font-medium"><?php echo e($appointment->service->name ?? 'General Checkup'); ?></p>
                            <p class="text-sm text-gray-600"><?php echo e($appointment->appointment_date->format('M d, Y')); ?> - Dr. <?php echo e($appointment->doctor->user->name); ?></p>
                        </div>
                        <span class="px-3 py-1 rounded text-xs font-semibold
                            <?php if($appointment->status === 'completed'): ?> bg-green-100 text-green-800
                            <?php elseif($appointment->status === 'scheduled'): ?> bg-[#0066cc] bg-opacity-20 text-[#003d82]
                            <?php else: ?> bg-[#fcd34d] bg-opacity-30 text-[#2d3748]
                            <?php endif; ?>">
                            <?php echo e(ucfirst($appointment->status)); ?>

                        </span>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Frenzy\veterinary_laravel\resources\views\pets\show.blade.php ENDPATH**/ ?>