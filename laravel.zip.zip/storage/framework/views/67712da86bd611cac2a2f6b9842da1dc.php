<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Veterinary Clinic Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            color: #333;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 20px;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            color: #2563eb;
        }
        .header p {
            margin: 5px 0 0 0;
            color: #666;
        }
        .stats-grid {
            display: table;
            width: 100%;
            margin-bottom: 30px;
        }
        .stats-row {
            display: table-row;
        }
        .stats-cell {
            display: table-cell;
            width: 25%;
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
            background-color: #f9f9f9;
        }
        .stats-cell h3 {
            margin: 0 0 5px 0;
            font-size: 14px;
            color: #333;
        }
        .stats-cell .number {
            font-size: 20px;
            font-weight: bold;
            color: #2563eb;
        }
        .section {
            margin-bottom: 30px;
            page-break-inside: avoid;
        }
        .section h2 {
            background-color: #2563eb;
            color: white;
            padding: 10px;
            margin: 0 0 15px 0;
            font-size: 16px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .footer {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            text-align: center;
            font-size: 10px;
            color: #666;
            border-top: 1px solid #ddd;
            padding: 10px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Veterinary Clinic Management System</h1>
        <p>Comprehensive Report - <?php echo e(date('F d, Y')); ?></p>
    </div>

    <!-- Summary Statistics -->
    <div class="section">
        <h2>Summary Statistics</h2>
        <div class="stats-grid">
            <div class="stats-row">
                <div class="stats-cell">
                    <h3>Total Pets</h3>
                    <div class="number"><?php echo e($stats['total_pets']); ?></div>
                </div>
                <div class="stats-cell">
                    <h3>Total Pet Owners</h3>
                    <div class="number"><?php echo e($stats['total_owners']); ?></div>
                </div>
                <div class="stats-cell">
                    <h3>Total Doctors</h3>
                    <div class="number"><?php echo e($stats['total_doctors']); ?></div>
                </div>
                <div class="stats-cell">
                    <h3>Total Appointments</h3>
                    <div class="number"><?php echo e($stats['total_appointments']); ?></div>
                </div>
            </div>
            <div class="stats-row">
                <div class="stats-cell">
                    <h3>Total Services</h3>
                    <div class="number"><?php echo e($stats['total_services']); ?></div>
                </div>
                <div class="stats-cell">
                    <h3>Medical Records</h3>
                    <div class="number"><?php echo e($stats['total_medical_records']); ?></div>
                </div>
                <div class="stats-cell">
                    <h3>Total Revenue</h3>
                    <div class="number">$<?php echo e(number_format($revenue_by_service->sum('total_revenue'), 2)); ?></div>
                </div>
                <div class="stats-cell">
                    <h3>Report Date</h3>
                    <div class="number"><?php echo e(date('M d, Y')); ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Revenue by Service -->
    <div class="section">
        <h2>Revenue by Service</h2>
        <table>
            <thead>
                <tr>
                    <th>Service Name</th>
                    <th>Total Revenue</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $revenue_by_service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($service->name); ?></td>
                    <td>$<?php echo e(number_format($service->total_revenue, 2)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="2" style="text-align: center;">No revenue data available</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Appointments by Status -->
    <div class="section">
        <h2>Appointments by Status</h2>
        <table>
            <thead>
                <tr>
                    <th>Status</th>
                    <th>Count</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $appointments_by_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e(ucfirst(str_replace('_', ' ', $status->status))); ?></td>
                    <td><?php echo e($status->count); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="2" style="text-align: center;">No appointment data available</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pets by Species -->
    <div class="section">
        <h2>Pets by Species</h2>
        <table>
            <thead>
                <tr>
                    <th>Species</th>
                    <th>Count</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $pets_by_species; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $species): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e(ucfirst($species->species)); ?></td>
                    <td><?php echo e($species->count); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="2" style="text-align: center;">No pet data available</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Recent Appointments -->
    <div class="section">
        <h2>Recent Appointments</h2>
        <table>
            <thead>
                <tr>
                    <th>Pet</th>
                    <th>Owner</th>
                    <th>Doctor</th>
                    <th>Service</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $recent_appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($appointment->pet->name); ?></td>
                    <td><?php echo e($appointment->pet->owner->user->name); ?></td>
                    <td><?php echo e($appointment->doctor->user->name); ?></td>
                    <td><?php echo e($appointment->service->name); ?></td>
                    <td><?php echo e($appointment->appointment_date->format('M d, Y')); ?></td>
                    <td><?php echo e($appointment->appointment_time); ?></td>
                    <td><?php echo e(ucfirst(str_replace('_', ' ', $appointment->status))); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" style="text-align: center;">No recent appointments</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="footer">
        <p>Generated on <?php echo e(date('F d, Y \a\t H:i:s')); ?> | Veterinary Clinic Management System</p>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Frenzy\veterinary_laravel\resources\views\reports\pdf.blade.php ENDPATH**/ ?>