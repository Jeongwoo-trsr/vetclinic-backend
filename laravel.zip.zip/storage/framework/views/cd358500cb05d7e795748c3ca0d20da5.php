

<?php $__env->startSection('title', 'Edit Pet'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-[#2d3748]">
            <i class="fas fa-edit text-[#fcd34d] mr-2"></i>Edit Pet: <?php echo e($pet->name); ?>

        </h1>
        <a href="<?php echo e(route('admin.pets')); ?>" class="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400">
            <i class="fas fa-arrow-left mr-2"></i>Back
        </a>
    </div>

    <div class="bg-white shadow-lg rounded-lg overflow-hidden">
        <!-- Header -->
        <div class="bg-[#1e3a5f] px-6 py-6">
            <h2 class="text-2xl font-bold text-white">
                <i class="fas fa-paw text-[#fcd34d] mr-2"></i>Update Pet Information
            </h2>
        </div>

        <!-- Form -->
        <div class="p-6">
            <?php if($errors->any()): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <ul class="list-disc list-inside">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('pets.update', $pet->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        <i class="fas fa-user text-[#d4931d] mr-1"></i>Pet Owner *
                    </label>
                    <select name="owner_id" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0066cc]">
                        <?php $__currentLoopData = \App\Models\PetOwner::with('user')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($owner->id); ?>" <?php echo e($pet->owner_id == $owner->id ? 'selected' : ''); ?>>
                                <?php echo e($owner->user->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-paw text-[#fcd34d] mr-1"></i>Pet Name *
                        </label>
                        <input type="text" name="name" value="<?php echo e(old('name', $pet->name)); ?>" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0066cc]">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-list text-[#d4931d] mr-1"></i>Species *
                        </label>
                        <input type="text" name="species" value="<?php echo e(old('species', $pet->species)); ?>" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0066cc]">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-dog text-[#fcd34d] mr-1"></i>Breed
                        </label>
                        <input type="text" name="breed" value="<?php echo e(old('breed', $pet->breed)); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0066cc]">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-birthday-cake text-[#d4931d] mr-1"></i>Age *
                        </label>
                        <input type="number" name="age" value="<?php echo e(old('age', $pet->age)); ?>" required min="0" max="30" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0066cc]">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-weight text-[#fcd34d] mr-1"></i>Weight (kg)
                        </label>
                        <input type="number" name="weight" value="<?php echo e(old('weight', $pet->weight)); ?>" step="0.01" min="0" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0066cc]">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-palette text-[#d4931d] mr-1"></i>Color
                        </label>
                        <input type="text" name="color" value="<?php echo e(old('color', $pet->color)); ?>" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0066cc]">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-venus-mars text-[#fcd34d] mr-1"></i>Gender *
                        </label>
                        <select name="gender" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0066cc]">
                            <option value="male" <?php echo e($pet->gender == 'male' ? 'selected' : ''); ?>>Male</option>
                            <option value="female" <?php echo e($pet->gender == 'female' ? 'selected' : ''); ?>>Female</option>
                        </select>
                    </div>
                  
                </div>

                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        <i class="fas fa-notes-medical text-[#d4931d] mr-1"></i>Medical Notes
                    </label>
                    <textarea name="medical_notes" rows="4" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0066cc]"><?php echo e(old('medical_notes', $pet->medical_notes)); ?></textarea>
                </div>

                <div class="flex justify-end gap-3 pt-4 border-t">
                    <a href="<?php echo e(route('admin.pets')); ?>" class="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 font-medium">
                        Cancel
                    </a>
                    <button type="submit" class="px-6 py-2 bg-[#0066cc] text-white rounded-lg hover:bg-[#003d82] font-medium">
                        <i class="fas fa-save mr-2 text-[#fcd34d]"></i>Update Pet
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Frenzy\veterinary_laravel\resources\views\pets\edit.blade.php ENDPATH**/ ?>