<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\Pet;
use App\Models\Service;
use App\Models\Doctor;
use App\Models\Notification;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class AppointmentController extends Controller
{
    public function index(Request $request)
    {
        $user = Auth::user();
        $status = $request->input('status');

        if ($user->role === 'admin') {
            $appointmentsQuery = Appointment::with(['pet.owner.user', 'doctor.user', 'service']);
            if ($status) {
                $appointmentsQuery->where('status', $status);
            }
            $appointments = $appointmentsQuery->orderBy('appointment_date', 'desc')->paginate(15);
        } elseif ($user->role === 'doctor') {
            $doctor = $user->doctor;
            $appointmentsQuery = Appointment::where('doctor_id', $doctor->id)->with(['pet.owner.user', 'service']);
            if ($status) {
                $appointmentsQuery->where('status', $status);
            }
            $appointments = $appointmentsQuery->orderBy('appointment_date', 'desc')->paginate(15);
        } else {
            $petOwner = $user->petOwner;
            $appointmentsQuery = Appointment::whereHas('pet', function ($q) use ($petOwner) {
                $q->where('owner_id', $petOwner->id);
            })->with(['pet', 'doctor.user', 'service']);
            if ($status) {
                $appointmentsQuery->where('status', $status);
            }
            $appointments = $appointmentsQuery->orderBy('appointment_date', 'desc')->paginate(15);
        }
        
        return view('appointments.index', compact('appointments'));
    }

    //create
    public function create()
    {
        $user = Auth::user();
        if ($user->role === 'pet_owner') {
            $petOwner = $user->petOwner;
            $pets = $petOwner->pets;
            $doctor = Doctor::first();
        } elseif ($user->role === 'admin') {
            $pets = Pet::with('owner')->get();
            $doctor = Doctor::first();
        } else {
            $pets = Pet::with('owner')->get();
            $doctor = $user->doctor;
        }
        $services = Service::where('is_active', true)->get();
        $doctors = Doctor::with('user')->get();
        return view('appointments.create', compact('pets', 'services', 'doctors', 'doctor'));
    }


    public function store(Request $request)
    {
        $request->validate([
            'pet_id' => 'required|exists:pets,id',
            'service_id' => 'required|exists:services,id',
            'doctor_id' => 'nullable|exists:doctors,id',
            'appointment_date' => 'required|date|after:today',
            'appointment_time' => 'required|date_format:H:i',
            'notes' => 'nullable|string|max:1000',
        ]);

        $user = Auth::user();
        $userRole = $user->role;
        
        // Verify pet ownership for pet owners
        if ($userRole === 'pet_owner') {
            $petOwner = $user->petOwner;
            $pet = Pet::where('id', $request->pet_id)
                ->where('owner_id', $petOwner->id)
                ->first();
            
            if (!$pet) {
                return back()->withErrors(['pet_id' => 'Invalid pet selection.']);
            }
        }

        $doctorId = $request->doctor_id;
        if (!$doctorId) {
            $defaultDoctor = Doctor::first();
            $doctorId = $defaultDoctor ? $defaultDoctor->id : null;
        }

        if (!$doctorId) {
            return back()->withErrors(['error' => 'No doctor available in the system.']);
        }

        // Validate time
        $time = Carbon::createFromFormat('H:i', $request->appointment_time);
        if ($time->hour < 8 || $time->hour >= 18) {
            return back()->withErrors(['appointment_time' => 'Appointments can only be scheduled between 8:00 AM and 6:00 PM.']);
        }

        // Check time conflicts
        $conflict = Appointment::where('doctor_id', $doctorId)
            ->where('appointment_date', $request->appointment_date)
            ->where('appointment_time', $request->appointment_time)
            ->where('status', '!=', 'cancelled')
            ->exists();

        if ($conflict) {
            return back()->withErrors(['appointment_time' => 'This time slot is already booked. Please select another time.']);
        }

        $appointmentStatus = ($userRole === 'pet_owner') ? 'pending' : 'scheduled';

        $appointment = Appointment::create([
            'pet_id' => $request->pet_id,
            'doctor_id' => $doctorId,
            'service_id' => $request->service_id,
            'appointment_date' => $request->appointment_date,
            'appointment_time' => $request->appointment_time,
            'notes' => $request->notes,
            'status' => $appointmentStatus,
        ]);

        $petOwnerName = $appointment->pet->owner->user->name;
        $petName = $appointment->pet->name;
        $date = $appointment->appointment_date->format('M d, Y');
        $time = $appointment->appointment_time;

        // NOTIFICATION
        if ($userRole === 'pet_owner') {
            // Pet owner created appointment - notif
            $users = User::where(function($query) {
                $query->where('role', 'admin')
                    ->orWhere('role', 'doctor');
            })->get();

            foreach ($users as $notifyUser) {
                $this->createNotification(
                    $notifyUser->id,
                    'appointment_request',
                    'New Appointment Request',
                    "{$petOwnerName} requested an appointment for {$petName} on {$date} at {$time}",
                    $appointment->id
                );
            }
            
            $successMessage = 'Appointment request submitted successfully. Waiting for approval.';
        } else {
            // Admin or Doctor created appointment - notif 
            $petOwnerUserId = $appointment->pet->owner->user_id;
            $this->createNotification(
                $petOwnerUserId,
                'appointment_scheduled',
                'Appointment Scheduled',
                "An appointment has been scheduled for {$petName} on {$date} at {$time}.",
                $appointment->id
            );
            
            $successMessage = 'Appointment scheduled successfully.';
        }

        //redirect route
        if ($userRole === 'pet_owner') {
            $redirectRoute = 'pet-owner.appointments';
        } elseif ($userRole === 'doctor') {
            $redirectRoute = 'doctor.appointments';
        } else {
            $redirectRoute = 'admin.appointments';
        }

        return redirect()->route($redirectRoute)->with('success', $successMessage);
    }

    //Display Appoinment
    public function show(Appointment $appointment)
    {
        $user = Auth::user();
        // Authorization
        if ($user->role === 'pet_owner') {
            $petOwner = $user->petOwner;
            if ($appointment->pet->owner_id !== $petOwner->id) {
                abort(403, 'Unauthorized action.');
            }
        } elseif ($user->role === 'doctor') {
            $doctor = $user->doctor;
            if ($appointment->doctor_id !== $doctor->id) {
                abort(403, 'Unauthorized action.');
            }
        }
        
        $appointment->load(['pet.owner.user', 'doctor.user', 'service']);
        
        return view('appointments.show', compact('appointment'));
    }

    // Show the form - edit
    public function edit(Appointment $appointment)
    {
        $user = Auth::user();
        if ($appointment->status === 'completed') {
            return back()->with('error', 'Completed appointments cannot be edited.');
        }
        
        if ($appointment->status === 'cancelled') {
            return back()->with('error', 'Cancelled appointments cannot be edited.');
        }
        
        // Authorization
        if ($user->role === 'pet_owner') {
            $petOwner = $user->petOwner;
            if ($appointment->pet->owner_id !== $petOwner->id) {
                abort(403, 'Unauthorized action.');
            }
            if ($appointment->status !== 'pending') {
                return back()->with('error', 'You can only edit pending appointments.');
            }   
            $pets = $petOwner->pets;
        } elseif ($user->role === 'doctor') {
            // Doctor authorization
            $doctor = $user->doctor;
            if ($appointment->doctor_id !== $doctor->id) {
                abort(403, 'Unauthorized action.');
            }
            $pets = Pet::with('owner')->get();
        } else {
            $pets = Pet::with('owner')->get();
        }
        
        $services = Service::where('is_active', true)->get();
        $doctors = Doctor::with('user')->get();
        
        return view('appointments.edit', compact('appointment', 'pets', 'services', 'doctors'));
    }

    // Update appointment
    public function update(Request $request, Appointment $appointment)
    {
        // Store old date, time, status 
        $oldDate = $appointment->appointment_date->format('Y-m-d');
        $oldTime = $appointment->appointment_time;
        $oldStatus = $appointment->status;
        
        if (!$request->filled('appointment_time')) {
            $request->merge(['appointment_time' => $oldTime]);
        }
        if (!$request->filled('appointment_date')) {
            $request->merge(['appointment_date' => $oldDate]);
        }
        
        $request->validate([
            'pet_id' => 'required|exists:pets,id',
            'service_id' => 'required|exists:services,id',
            'doctor_id' => 'nullable|exists:doctors,id',
            'appointment_date' => 'required|date|after:today',
            'appointment_time' => 'required|date_format:H:i',
            'notes' => 'nullable|string|max:1000',
            'status' => 'nullable|in:pending,scheduled,completed,cancelled',
        ]);

        $user = Auth::user();
        $userRole = $user->role;

        if ($appointment->status === 'completed') {
            return back()->with('error', 'Completed appointments cannot be edited.');
        }
        if ($appointment->status === 'cancelled') {
            return back()->with('error', 'Cancelled appointments cannot be edited.');
        }
        
        // Authorization - pet ownerr
        if ($userRole === 'pet_owner') {
            $petOwner = $user->petOwner;
            
            // Verify pet owner
            $pet = Pet::where('id', $request->pet_id)
                ->where('owner_id', $petOwner->id)
                ->first();
            
            if (!$pet) {
                return back()->withErrors(['pet_id' => 'Invalid pet selection.']);
            }
            if ($appointment->status !== 'pending') {
                return back()->with('error', 'You can only edit pending appointments.');
            }
        }

        $doctorId = $request->doctor_id ?? $appointment->doctor_id;
        $dateChanged = $request->appointment_date != $oldDate;
        $timeChanged = $request->appointment_time != $oldTime;
        
        if ($dateChanged || $timeChanged) {
            // Validate time
            $time = Carbon::createFromFormat('H:i', $request->appointment_time);
            if ($time->hour < 8 || $time->hour >= 18) {
                return back()->withErrors(['appointment_time' => 'Appointments can only be scheduled between 8:00 AM and 6:00 PM.']);
            }

            $conflict = Appointment::where('doctor_id', $doctorId)
                ->where('appointment_date', $request->appointment_date)
                ->where('appointment_time', $request->appointment_time)
                ->where('status', '!=', 'cancelled')
                ->where('id', '!=', $appointment->id)
                ->exists();

            if ($conflict) {
                return back()->withErrors(['appointment_time' => 'This time slot is already booked. Please select another time.']);
            }
        }

        $updateData = [
            'pet_id' => $request->pet_id,
            'doctor_id' => $doctorId,
            'service_id' => $request->service_id,
            'appointment_date' => $request->appointment_date,
            'appointment_time' => $request->appointment_time,
            'notes' => $request->notes,
        ];

        if (in_array($userRole, ['admin', 'doctor']) && $request->has('status')) {
            if ($oldStatus === 'completed' || $oldStatus === 'cancelled') {
                return back()->with('error', ucfirst($oldStatus) . ' appointments cannot be edited.');
            }
            $updateData['status'] = $request->status;
        }

        $appointment->update($updateData);

        if (in_array($userRole, ['admin', 'doctor'])) {
            $petOwnerUserId = $appointment->pet->owner->user_id;
            $petName = $appointment->pet->name;
            $newDate = $appointment->appointment_date->format('M d, Y');
            $newTime = $appointment->appointment_time;
            
            $changes = [];
            if ($dateChanged) {
                $changes[] = "date changed to {$newDate}";
            }
            if ($timeChanged) {
                $changes[] = "time changed to {$newTime}";
            }
            if ($request->has('status') && $request->status != $oldStatus) {
                $changes[] = "status changed to " . ucfirst($request->status);
            }
            
            if (!empty($changes)) {
                $changeMessage = implode(', ', $changes);
                $this->createNotification(
                    $petOwnerUserId,
                    'appointment_updated',
                    'Appointment Updated',
                    "Your appointment for {$petName} has been updated: {$changeMessage}.",
                    $appointment->id
                );
            }
        }
        elseif ($userRole === 'pet_owner') {
            if ($dateChanged || $timeChanged) {
                $petName = $appointment->pet->name;
                $petOwnerName = $user->name;
                $newDate = $appointment->appointment_date->format('M d, Y');
                $newTime = $appointment->appointment_time;
                
                $users = User::where(function($query) {
                    $query->where('role', 'admin')
                        ->orWhere('role', 'doctor');
                })->get();

                foreach ($users as $notifyUser) {
                    $this->createNotification(
                        $notifyUser->id,
                        'appointment_updated',
                        'Appointment Updated by Owner',
                        "{$petOwnerName} updated appointment for {$petName} to {$newDate} at {$newTime}",
                        $appointment->id
                    );
                }
            }
        }

        //redirect route
        if ($userRole === 'pet_owner') {
            $redirectRoute = 'pet-owner.appointments';
        } elseif ($userRole === 'doctor') {
            $redirectRoute = 'doctor.appointments';
        } else {
            $redirectRoute = 'admin.appointments';
        }

        return redirect()->route($redirectRoute)
            ->with('success', 'Appointment updated successfully.');
    }

    //delete
    public function destroy(Appointment $appointment)
    {
        $user = Auth::user();
        $userRole = $user->role;
        
        // Authorization
        if ($userRole === 'pet_owner') {
            $petOwner = $user->petOwner;
            if ($appointment->pet->owner_id !== $petOwner->id) {
                return back()->with('error', 'Unauthorized action.');
            }
            if ($appointment->status !== 'pending') {
                return back()->with('error', 'You can only delete pending appointments.');
            }
        }
        
        $appointment->delete();
        
        //redirect route
        if ($userRole === 'pet_owner') {
            $redirectRoute = 'pet-owner.appointments';
        } elseif ($userRole === 'doctor') {
            $redirectRoute = 'doctor.appointments';
        } else {
            $redirectRoute = 'admin.appointments';
        }

        return redirect()->route($redirectRoute)
            ->with('success', 'Appointment deleted successfully.');
    }


    public function getAvailableTimeSlots(Request $request)
    {
        $date = $request->input('date');
        $doctorId = $request->input('doctor_id');
        
        if (!$date) {
            return response()->json(['error' => 'Date is required'], 400);
        }
        if ($doctorId) {
            $doctor = Doctor::find($doctorId);
        } else {
            $doctor = Doctor::first();
        }
        if (!$doctor) {
            return response()->json(['error' => 'No doctor available'], 404);
        }

        $bookedTimes = Appointment::where('doctor_id', $doctor->id)
            ->where('appointment_date', $date)
            ->where('status', '!=', 'cancelled')
            ->pluck('appointment_time')
            ->map(function($time) {
                return Carbon::parse($time)->format('H:i');
            })
            ->toArray();

        $timeSlots = [];
        $start = Carbon::createFromFormat('H:i', '08:00');
        $end = Carbon::createFromFormat('H:i', '18:00');

        while ($start < $end) {
            $timeString = $start->format('H:i');
            $timeSlots[] = [
                'time' => $timeString,
                'display' => $start->format('g:i A'),
                'available' => !in_array($timeString, $bookedTimes)
            ];
            $start->addMinutes(30);
        }

        return response()->json($timeSlots);
    }


    public function calendar()
    {
        $user = Auth::user();
        
        if ($user->role === 'admin') {
            $appointments = Appointment::with(['pet.owner.user', 'doctor.user', 'service'])->get();
        } elseif ($user->role === 'doctor') {
            $doctor = $user->doctor;
            $appointments = Appointment::where('doctor_id', $doctor->id)
                ->with(['pet.owner.user', 'service'])
                ->get();
        } else {
            $petOwner = $user->petOwner;
            $appointments = Appointment::whereHas('pet', function ($q) use ($petOwner) {
                $q->where('owner_id', $petOwner->id);
            })
            ->with(['pet', 'doctor.user', 'service'])
            ->get();
        }
        
        return view('appointments.calendar', compact('appointments'));
    }


    private function createNotification($userId, $type, $title, $message, $appointmentId = null)
    {
        Notification::create([
            'user_id' => $userId,
            'type' => $type,
            'title' => $title,
            'message' => $message,
            'appointment_id' => $appointmentId,
        ]);
    }

    
    private function notifyAdminsAndDoctors($type, $title, $message, $appointmentId = null)
    {
        $users = User::whereIn('role', ['admin', 'doctor'])->get();
        
        foreach ($users as $user) {
            $this->createNotification($user->id, $type, $title, $message, $appointmentId);
        }
    }

    public function requestCancellation(Request $request, Appointment $appointment)
    {
        // Validate cancellation reason
        $request->validate([
            'cancellation_reason' => 'required|string|max:500',
        ]);

        $user = Auth::user();
        
        if ($user->role === 'pet_owner') {
            $petOwner = $user->petOwner;
            if ($appointment->pet->owner_id !== $petOwner->id) {
                return redirect()->route('pet-owner.appointments')
                    ->with('error', 'Unauthorized action.');
            }
        }

        if ($appointment->status === 'completed') {
            return back()->with('error', 'Cannot cancel a completed appointment.');
        }

        if ($appointment->status === 'cancelled') {
            return back()->with('error', 'This appointment is already cancelled.');
        }

        if ($appointment->cancellation_status === 'pending') {
            return back()->with('error', 'A cancellation request is already pending for this appointment.');
        }

        $appointment->update([
            'cancellation_status' => 'pending',
            'cancellation_reason' => $request->cancellation_reason,
            'cancellation_requested_at' => now(),
        ]);

        $petOwnerName = Auth::user()->name;
        $petName = $appointment->pet->name;
        $date = $appointment->appointment_date->format('M d, Y');
        
        $this->notifyAdminsAndDoctors(
            'cancellation_request',
            'Cancellation Request',
            "{$petOwnerName} requested to cancel appointment for {$petName} on {$date}",
            $appointment->id
        );

        return redirect()->route('pet-owner.appointments')
            ->with('success', 'Cancellation request submitted successfully.');
    }


    public function approveCancellation(Appointment $appointment)
    {
        $user = Auth::user();
        
        if (!in_array($user->role, ['admin', 'doctor'])) {
            return back()->with('error', 'Unauthorized action.');
        }
        if ($appointment->cancellation_status !== 'pending') {
            return back()->with('error', 'No pending cancellation request for this appointment.');
        }

        // Update appointment status
        $appointment->update([
            'status' => 'cancelled',
            'cancellation_status' => 'approved',
        ]);

        $petOwnerUserId = $appointment->pet->owner->user_id;
        $petName = $appointment->pet->name;
        $date = $appointment->appointment_date->format('M d, Y');
        
        $this->createNotification(
            $petOwnerUserId,
            'cancellation_approved',
            'Cancellation Approved',
            "Your cancellation request for {$petName}'s appointment on {$date} has been approved.",
            $appointment->id
        );

        $redirectRoute = $user->role === 'doctor' ? 'doctor.appointments' : 'admin.appointments';
        return redirect()->route($redirectRoute)->with('success', 'Cancellation request approved.');
    }

    public function declineCancellation(Request $request, Appointment $appointment)
    {
        $user = Auth::user();
        if (!in_array($user->role, ['admin', 'doctor'])) {
            return back()->with('error', 'Unauthorized action.');
        }
        if ($appointment->cancellation_status !== 'pending') {
            return back()->with('error', 'No pending cancellation request for this appointment.');
        }
        $appointment->update([
            'cancellation_status' => 'declined',
        ]);

        $petOwnerUserId = $appointment->pet->owner->user_id;
        $petName = $appointment->pet->name;
        $date = $appointment->appointment_date->format('M d, Y');
        
        $this->createNotification(
            $petOwnerUserId,
            'cancellation_declined',
            'Cancellation Declined',
            "Your cancellation request for {$petName}'s appointment on {$date} has been declined.",
            $appointment->id
        );

        $redirectRoute = $user->role === 'doctor' ? 'doctor.appointments' : 'admin.appointments';
        return redirect()->route($redirectRoute)->with('success', 'Cancellation request declined.');
    }

    public function markAsCompleted(Appointment $appointment)
    {
        $user = Auth::user();
        
        if (!in_array($user->role, ['admin', 'doctor'])) {
            return back()->with('error', 'Unauthorized action.');
        }
        if ($user->role === 'doctor' && $appointment->doctor_id !== $user->doctor->id) {
            return back()->with('error', 'Unauthorized action.');
        }

        $appointment->update(['status' => 'completed']);
        $petOwnerUserId = $appointment->pet->owner->user_id;
        $petName = $appointment->pet->name;
        $date = $appointment->appointment_date->format('M d, Y');
        
        $this->createNotification(
            $petOwnerUserId,
            'appointment_completed',
            'Appointment Completed',
            "Your appointment for {$petName} on {$date} has been marked as completed.",
            $appointment->id
        );

        $redirectRoute = $user->role === 'doctor' ? 'doctor.appointments' : 'admin.appointments';
        return redirect()->route($redirectRoute)
            ->with('success', 'Appointment marked as completed successfully.');
    }

    //mark as
    public function markAsCancelled(Appointment $appointment)
    {
        $user = Auth::user();
        if (!in_array($user->role, ['admin', 'doctor'])) {
            return back()->with('error', 'Unauthorized action.');
        }
        if ($user->role === 'doctor' && $appointment->doctor_id !== $user->doctor->id) {
            return back()->with('error', 'Unauthorized action.');
        }

        $appointment->update(['status' => 'cancelled']);
        $petOwnerUserId = $appointment->pet->owner->user_id;
        $petName = $appointment->pet->name;
        $date = $appointment->appointment_date->format('M d, Y');
        
        $this->createNotification(
            $petOwnerUserId,
            'appointment_cancelled',
            'Appointment Cancelled',
            "Your appointment for {$petName} on {$date} has been cancelled.",
            $appointment->id
        );

        $redirectRoute = $user->role === 'doctor' ? 'doctor.appointments' : 'admin.appointments';
        return redirect()->route($redirectRoute)
            ->with('success', 'Appointment cancelled successfully.');
    }
}